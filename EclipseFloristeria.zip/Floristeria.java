package clase;

public class floristeria {
//metodo constructor
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hola mundo");
		System.out.println("Mi nombre es Santiago");
	}

}

