package floristeria;

public class Florsiteria {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		casa andreacasa= new casa("Blanca", 4, 2, true, true);
		System.out.println(andreacasa.describir());
		andreacasa.pintar("Le agrego el T1");
		System.out.println(andreacasa.describir());
	}

}
